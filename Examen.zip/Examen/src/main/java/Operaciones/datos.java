/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operaciones;

/**
 *
 * @author Francisco Luciano
 */
public class datos {
     private int Suma;
    private int Numero = 0;
    public int hashSimple(String Matricula){
      String U = Matricula;
      String E = U.substring(0,1);
      String h = U.substring(1,2);
      String r = U.substring(2,3);
      String t = U.substring(3,4);
      String w = U.substring(4,5);
      
      int Q = Integer.parseInt(E);
      int W = Integer.parseInt(h);
      int R = Integer.parseInt(r);
      int T = Integer.parseInt(t);
      int Y = Integer.parseInt(w);
      
      this.Suma = Q+W+R+T+Y;
      digitoVerificador(this.Suma);
      return this.Suma;
    }
    
    public void digitoVerificador(int numero){
     
        if(numero <= 19){
            this.Numero=0;
        }
        if((20 > numero) && (numero<29)){
            this.Numero=1;
        }
        if(numero > 30){
            this.Numero=2;
        }
       System.out.println(this.Numero);
    }
    
}
