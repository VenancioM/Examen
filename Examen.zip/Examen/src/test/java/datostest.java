/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Operaciones.datos;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class datostest {
    datos E = new datos();
    @Test
    public void TestHash6() {
        int esperado = 18;
        int actual = E.hashSimple("56511");
        assertEquals(esperado,actual);
    }
     @Test//Mio
    public void TestHash7() {
        int esperado = 23;
        int actual = E.hashSimple("47147");
        assertEquals(esperado,actual);
    }
     @Test
    public void TestHash8() {
        int esperado = 29;
        int actual = E.hashSimple("58754");
        assertEquals(esperado,actual);
    }
     @Test
    public void TestHash9() {
        int esperado = 25;
        int actual = E.hashSimple("58813");
        assertEquals(esperado,actual);
    }
     @Test
    public void TestHash10() {
        int esperado = 23;
        int actual = E.hashSimple("46931");
        assertEquals(esperado,actual);
    }
}
